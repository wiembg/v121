
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyA47ryp_pzaWkb6edAu8Cko8TaXf79ThSA",
    authDomain: "v-one-to-one.firebaseapp.com",
    databaseURL: "https://v-one-to-one.firebaseio.com",
    projectId: "v-one-to-one",
    storageBucket: "v-one-to-one.appspot.com",
    messagingSenderId: "26982029114"
  };
  firebase.initializeApp(config);

// Firebase Variables
var auth = firebase.auth();

// on state changed


// •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
// signup form
// •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
var singoutButton = document.querySelector("#signout");
var currentEmail = document.querySelector("#current-email");

var singupForm = document.querySelector("#signup-form");
var userName = document.querySelector("#username");
var email = document.querySelector("#email");
var password = document.querySelector("#password");
var singupButton = document.querySelector("#signup");
var firstname = document.querySelector("#firstname");
var lastname = document.querySelector("#lastname");
var phoneNumber = document.querySelector("#phoneNumber");
var username = document.querySelector("#username");
var birthday = document.querySelector("#birthday");
var city = document.querySelector("#city");
var Adress = document.querySelector("#dress");
var gender = document.querySelector("#gender");


singupButton.addEventListener("click", clickSignupButton);
singoutButton.addEventListener("click", clickSignoutButton);


function clickSignupButton(){

  //signup firebase method
  auth.createUserWithEmailAndPassword(email.value, password.value)
  .catch(function(error) {
        // Handle Errors here.

         alert('The coachh is created successfully!');
        var errorCode = error.code;
        var errorMessage = error.message;
        // ...
      });
  

    auth.onAuthStateChanged(firebaseUser => {
  // check email
   
//var type= subject.options[subject.selected].text;

  if(firebaseUser){
   
    
     var uid =firebase.auth().currentUser.uid;
     firebase.database().ref('coachs/'+ uid).set({
       adresse: email.value,
        firstName: firstname.value,
        lastName : lastname.value,
        phoneNumber : phoneNumber.value,
        username : username.value,
        birthday : birthday.value,
        city:city.value,
        adress:adress.value,
        gender:gender.value
            }); 
   alert('The coach is created successfully!');
   //reload_page();
  }

});

}





// Signout function
function clickSignoutButton(){
  auth.signOut()
}


// •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
// singin form
// •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
