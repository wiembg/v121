
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyA47ryp_pzaWkb6edAu8Cko8TaXf79ThSA",
    authDomain: "v-one-to-one.firebaseapp.com",
    databaseURL: "https://v-one-to-one.firebaseio.com",
    projectId: "v-one-to-one",
    storageBucket: "v-one-to-one.appspot.com",
    messagingSenderId: "26982029114"
  };
  firebase.initializeApp(config);

         /*function insertData(email ) {
            firebase.database().ref('profile/'+ email).set({
               
				email: email
				
            });          

        }*/
		
	
		
		$('#next').on('click', function () {
            var email = $('#email').val();
			      var password = $('#password').val();
            
            document.getElementById("email").value = "";
            document.getElementById("password").value = "";
            firebase.auth().signInWithEmailAndPassword(email, password);
            firebase.auth().signOut().then(function() {
            console.log('Signed Out');
          }, function(error) {
            console.error('Sign Out Error', error);
          });
        });


		firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  alert('please register now');
  // ...
});

		

    
    $('#next1').on('click', function () {
            var email1 = $('#email').val();
      var password1 = $('#password').val();
            
            document.getElementById("email1").value = "";
            document.getElementById("password1").value = "";
            firebase.auth().signInWithEmailAndPassword(email1, password1);
            firebase.auth().signOut().then(function() {
              console.log('Signed Out');
            }, function(error) {
              console.error('Sign Out Error', error);
            });
        });


    firebase.auth().signInWithEmailAndPassword(email1, password1).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // ...
});
    
		























 






