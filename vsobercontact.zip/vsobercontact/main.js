// Initialize Firebase
  
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyA47ryp_pzaWkb6edAu8Cko8TaXf79ThSA",
    authDomain: "v-one-to-one.firebaseapp.com",
    databaseURL: "https://v-one-to-one.firebaseio.com",
    projectId: "v-one-to-one",
    storageBucket: "v-one-to-one.appspot.com",
    messagingSenderId: "26982029114"
  };
  firebase.initializeApp(config);

// Reference messages collection
var messagesRef = firebase.database().ref('messages on public');

// Listen for form submit
document.getElementById('contactForm').addEventListener('submit', submitForm);

// Submit form
function submitForm(e){
  e.preventDefault();

  // Get values
  var name = getInputVal('name');

  var email = getInputVal('email');
 
  var message = getInputVal('message');

  // Save message
  saveMessage(name,  email, message);

  // Show alert
  document.querySelector('.alert').style.display = 'block';

  // Hide alert after 3 seconds
  setTimeout(function(){
    document.querySelector('.alert').style.display = 'none';
  },3000);

  // Clear form
  document.getElementById('contactForm').reset();
}

// Function to get get form values
function getInputVal(id){
  return document.getElementById(id).value;
}

// Save message to firebase
function saveMessage(name, email, message){
  var newMessageRef = messagesRef.push();
  newMessageRef.set({
    name: name,
   
    email:email,

    message:message
  });
}